Alauda Preset Pack Vol.1
==================================

Twelve public Genre presets. This is a convenience pack that makes it easier
to try Alauda's settings. Anyone may download and use it free of charge.

Nothing in Alauda itself is held back: the plug-in is fully functional
without this pack. What the pack adds is curated combinations that switch
all five voicing pages -- Enhance, EQ, Saturation, Analog and Reverb -- in
one move.

The ten factory Genre presets that ship with Alauda (Classical, Jazz, Pop
and so on) set Enhance and EQ only, and inherit whatever Saturation, Analog
and Reverb settings are already in place. All twelve presets here carry
complete settings for every one of the five pages.


Installing
----------

1. Open foobar2000 Preferences -> DSP -> Alauda
2. Go to the Profiles page and open the Genre list. Its last entry is
   [Manage Presets...]; choose it to open the Genre Preset Manager.
3. In that window, press [Folder...]. Your user preset folder opens in
   Explorer (it is created if missing).
4. Copy every .aldp file from this pack's genre folder into it.
5. Return to the Preset Manager. The list rescans automatically and the
   twelve presets appear, both there and in the Genre dropdown.

You can also load files one at a time with [Import...] in the same
window.

Install location, for reference:
  <foobar2000 profile>\presets\user\genre\

To uninstall, delete the .aldp files from that folder. The pack writes
nothing else anywhere.


What is in the pack
-------------------

-- Listening situations

01 Late Night Quiet
    To restore what thins out at low level late at night, Night EQ provides
    the base and a light Enhance Warm (35) sits on top of it. Saturation is
    off to keep things quiet, and Analog uses Smooth Glue for cohesion only.

02 Focus Work
    To stay out of the way while you work, Gentle Clear EQ and Enhance Clean
    are both kept minimal (25). A moving image is distracting, so Center
    Focus holds it steady and Saturation and Reverb are off.

03 Earbuds Commute
    To lift the bands that background noise swallows on earbuds, Loudness EQ
    and Bass Punch work together, with Enhance Forward (45) bringing the
    upper mids out in front.

04 Loud Session
    To keep high-level playback from turning harsh, Smooth EQ and Enhance
    Smooth take the edge off the top. Triode Single Velvet then adds a light
    harmonic layer so the result does not sound hollow.

-- Source and era

05 Vinyl Warmth
    To get the character of an analogue record, Tape Slow Glue (7.5 ips) is
    pushed to 55 while Vintage Mid EQ and Smooth Glue (60) thicken the
    midrange. This is the most heavily coloured preset in the pack.

06 Early Digital Relief
    To settle the harsh top end of early CD transfers, Soft Air EQ and
    Enhance Smooth round it off, and Smooth Air tidies the texture above.

07 Live Recording Lift
    To bring distant voices forward in live and audience recordings, Clear EQ
    is paired with Enhance Vocal. Wide Field opens the image so the venue is
    audible, and Tight Ambience at Amount 8 sets the distance without
    leaving a tail.

08 Mono Recording Depth
    To give a flat old mono recording some depth, Small Chamber is added at
    Amount 12. Warm EQ and Smooth Air underneath soften the hardness such
    sources usually have.

-- Genres beyond the ten factory ones

09 Anime Song Dense
    To untangle a dense anime-song or J-pop mix, Pop Polish EQ and Enhance
    Forward define the edges while Tape Master Punch holds the density
    together. Center Focus keeps the middle from saturating.

10 Metal Clarity
    To keep parts audible under distorted guitars, Tight Low End EQ firms up
    the bottom while Pentode Balanced Clear and Enhance Energy Push improve
    separation in the upper mids.

11 Synth Vocal Clean
    To extend the top of vocal synth and programmed material, Clear EQ works
    with Enhance Airy and Smooth Air. Triode Single Velvet stays light (25)
    so the result does not turn hard.

12 Orchestral Depth
    To open up orchestral and film scores, Cinema Depth EQ and Enhance
    Acoustic form the base, Wide Field provides width, and Concert Hall at
    Amount 10 supplies the space. Saturation is off to preserve the original
    texture.


Notes
-----

- Treat each preset as a starting point. Move any control afterwards and
  save the result as your own preset with [Save As].
- Only 07, 08 and 12 ship with Reverb enabled, all at Amount 8-12%. Lower
  the Amount if it is still too much.
- Presets that ship with Reverb off still carry Amount 25%, so switching
  Reverb on afterwards is immediately audible.
- If levels run hot, check that Auto Headroom and the Safety Limiter are
  enabled on the Output page.


Terms
-----

The pack is free for personal and commercial use. Redistribution is governed
by EULA_jp.txt / EULA_en.txt bundled with Alauda.
The included .aldp preset files may be freely copied, modified, and
redistributed under Article 4, paragraph 3 of the EULA. You may also
redistribute a package containing only these preset files and their
accompanying documentation, including this readme.

Every .aldp file is UTF-8 JSON text. It contains no paths, no scripts and
no binary payload, so you can read exactly what it changes.
