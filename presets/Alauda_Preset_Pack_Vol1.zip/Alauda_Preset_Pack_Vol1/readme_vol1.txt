Alauda Preset Pack Vol.1
==================================

Genre（ジャンル）プリセット12種の公開パックです。Alaudaの設定を試しやすく
するための補助的なプリセット集で、誰でも無償でダウンロードして利用できます。

Alauda 本体の音質・機能には一切の制限がありません。このパックが無くても
Alauda はフル機能で動作します。本パックは「Enhance / EQ / Saturation /
Analog / Reverb の5ページを一度に切り替える、作り込み済みの組み合わせ」を
まとめたものです。

本体に同梱されている Genre のファクトリープリセット（Classical / Jazz / Pop
など10種）は Enhance と EQ だけを設定し、Saturation・Analog・Reverb は現在の
設定をそのまま引き継ぎます。本パックの12種は 5ページすべてを保持します。


インストール
------------

1. foobar2000 の 環境設定 → DSP → Alauda を開く
2. 「プロファイル」ページのジャンル一覧を開き、最後の項目
   [Manage Presets...] を選ぶ（ジャンルのプリセットマネージャーが
   開きます）
3. そのウィンドウで [Folder...] ボタンを押す
   （ユーザープリセットフォルダーがエクスプローラーで開きます。
     フォルダーが無い場合は自動的に作成されます）
4. 本パックの genre フォルダーに入っている .aldp ファイルを、開いた
   フォルダーにすべてコピーする
5. プリセットマネージャーに戻ると自動で再スキャンされ、一覧と
   ジャンルのドロップダウンの両方に12種が追加されます

同じウィンドウの [Import...] ボタンから .aldp を1つずつ読み込むことも
できます。

インストール先（参考）:
  <foobar2000 プロファイル>\presets\user\genre\

アンインストールは、上記フォルダーから .aldp ファイルを削除するだけです。
Alauda 本体には何も書き込みません。


収録プリセット
--------------

■ 聴取シーン別

01 Late Night Quiet
    夜間の小音量再生で痩せて聞こえる帯域を補うために、Night EQ を土台に
    して Enhance Warm を控えめ（35）に重ねています。静けさを保つため
    Saturation はオフにし、Analog は Smooth Glue でまとまりだけを
    与えています。

02 Focus Work
    作業の邪魔にならない BGM にするために、Gentle Clear EQ と Enhance
    Clean を最小限（25）にとどめています。音像が揺れると気が散るため、
    Center Focus で定位を中央寄りに安定させ、Saturation と Reverb は
    オフにしています。

03 Earbuds Commute
    騒音下のイヤホン再生で埋もれる帯域を持ち上げるために、Loudness EQ と
    Bass Punch を組み合わせ、Enhance Forward（45）で中高域を前に
    出しています。

04 Loud Session
    大音量でも刺さらないようにするために、Smooth EQ と Enhance Smooth で
    高域の角を落としています。そのままでは物足りなくなるので、Triode
    Single Velvet の軽い倍音で厚みを補っています。

■ 音源の年代・状態別

05 Vinyl Warmth
    アナログ盤の質感を出すために、Tape Slow Glue（7.5ips）を強め（55）に
    使い、Vintage Mid EQ と Smooth Glue（60）で中域を厚くしています。
    本パックで最も色付けの強いプリセットです。

06 Early Digital Relief
    初期 CD 期のきつい高域を落ち着かせるために、Soft Air EQ と Enhance
    Smooth で上を丸め、Smooth Air で高域の質感を整えています。

07 Live Recording Lift
    ライブ録音や観客録音で遠い声を前に出すために、Clear EQ と Enhance
    Vocal を組み合わせています。会場の広がりを感じられるように Wide Field
    を加え、距離感を整えるために Tight Ambience を Amount 8 とごく薄く
    重ねています。

08 Mono Recording Depth
    平板になりがちな古いモノラル録音に奥行きを与えるために、Small Chamber
    を Amount 12 で薄く加えています。素材の硬さを和らげるため、土台には
    Warm EQ と Smooth Air を使っています。

■ ジャンル追加分（ファクトリープリセットの10ジャンルに無いもの）

09 Anime Song Dense
    密度の高いアニソン・J-POP のミックスを整理するために、Pop Polish EQ と
    Enhance Forward で輪郭を出し、Tape Master Punch で密度を保ったまま
    まとめています。中央が飽和しないように Center Focus を併用しています。

10 Metal Clarity
    歪みギターの中で各パートを聞き分けられるようにするために、Tight Low
    End EQ で低域を締め、Pentode Balanced Clear と Enhance Energy Push で
    中高域の分離を上げています。

11 Synth Vocal Clean
    ボカロや打ち込み系の高域を伸ばすために、Clear EQ と Enhance Airy を
    組み合わせ、Smooth Air で上を広げています。硬くならないように Triode
    Single Velvet は弱め（25）にとどめています。

12 Orchestral Depth
    オーケストラや劇伴の奥行きを出すために、Cinema Depth EQ と Enhance
    Acoustic を土台にし、Wide Field で横の広がりを、Concert Hall を
    Amount 10 でごく薄く重ねて空間を作っています。原音の質感を保つため
    Saturation はオフです。


使い方のヒント
--------------

・プリセットは出発点としてお使いください。読み込んだあとに各ページの
  つまみを動かせば、そのまま自分用の設定として [Save As] で保存できます。
・Reverb が有効なのは 07 / 08 / 12 の3つだけで、いずれも Amount は
  8〜12% とごく薄い設定です。それでも強く感じる場合は Amount を
  下げてください。
・Reverb をオフで収録しているプリセットも Amount 25% を保持しています。
  Reverb を後から有効にすると、すぐに効果が分かるようにしてあります。
・音量が上がりすぎる場合は、Output ページの Auto Headroom と Safety
  Limiter が有効になっているかご確認ください。


取り扱い
--------

本パックは個人・商用を問わず無償で利用できます。ファイルの再配布については、
Alauda に同梱される EULA_jp.txt / EULA_en.txt に従ってください。
本パックに含まれる .aldp プリセットファイルは、EULA第4条第3項の条件に従い、
無償で複製、改変、再配布、転載及び送信できます。本説明書を含む、これらの
プリセットファイルと付随する説明文書だけを収録した配布物も再配布できます。

各 .aldp ファイルは UTF-8 の JSON テキストで、パスもスクリプトも
バイナリも含みません。中身は自由に確認できます。
