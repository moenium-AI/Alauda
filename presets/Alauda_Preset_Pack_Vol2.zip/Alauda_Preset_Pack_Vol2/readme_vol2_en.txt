Alauda Preset Pack Vol.2 - Module Presets
===================================================

Where Vol.1 switches all five voicing pages at once, Vol.2 is for people who
build their own chain: presets for one page at a time. Thirty-eight in all.

  genre/       6   More Genre presets in the Vol.1 format (13-18)
  saturation/  9   Voicings the shipped character grid does not contain
  enhance/     5   All five bands placed by hand, one core at a time
  analog/      5   Settings that depend on knowing where a control acts
  reverb/      7   Tail shape: early/late balance, low and high decay
  eq/          6   Curves that move band type, centre and Q, not just gain

As with Vol.1, nothing in Alauda itself is held back. The plug-in is fully
functional without either pack.


Installing
----------

There is one folder per page. Files placed in the wrong folder will not show
up, so match the folder name to the page.

1. Open foobar2000 Preferences -> DSP -> Alauda
2. On the page you want (Saturation, say), open the preset list and choose
   the last entry, [Manage Presets...]
3. In the preset manager that opens, press [Folder...]. That page's own user
   preset folder opens (it is created if missing).
4. Copy the .aldp files from this pack's folder of the same name (saturation)
   into it.
5. Return to the preset manager. It rescans automatically and the presets
   appear both in its list and in the page's dropdown.

The genre folder goes to the Genre list on the Profiles page, the same way
Vol.1 does.

Install locations, for reference:
  <foobar2000 profile>\presets\user\saturation\
  <foobar2000 profile>\presets\user\enhance\
  <foobar2000 profile>\presets\user\analog\
  <foobar2000 profile>\presets\user\reverb\
  <foobar2000 profile>\presets\user\eq\
  <foobar2000 profile>\presets\user\genre\

To uninstall, delete the .aldp files from those folders.


-- genre/ Genre presets (6)

13 Spoken Word
    To make audiobooks, podcasts and talk easy to follow, Vocal Polish EQ
    works with Enhance Vocal and Center Focus holds the voice in the middle.
    Saturation and Reverb are off so nothing competes with the speech.

14 Small Speakers
    To make up for the bass a laptop or Bluetooth speaker cannot produce,
    Mid Fullness EQ and Bass Punch build the body in the low mids instead of
    reaching for a band the driver will never reach.

15 Chiptune Retro
    To sharpen the edges of game music and chiptune, Synth Punch EQ works
    with Enhance Energy Push, and Pentode Single Edge adds a light
    distortion.

16 City Pop Night
    For city pop and AOR heard at night, Warm EQ and Tape Studio Body are
    layered with Smooth Glue to give weight that stays calm.

17 Piano Solo
    To keep solo piano and chamber music sounding natural, Acoustic EQ and
    Enhance Acoustic form the base and Medium Chamber is added at Amount 10.

18 Big Band Swing
    To bring big-band horns forward, Forward EQ works with Enhance Rich and
    Transformer Steel Warmth supplies the core. Live Room at Amount 8 adds
    the sense of a venue.


-- saturation/ Saturation (9)

Every shipped character adds weight low and density mid. These nine take the
band controls negative, which is where that grid never goes. One per Mode.

  Lean Low Dense Mid
      To add density to material that already has enough bass, the low band
      of Tape 15 ips is taken negative and only the midrange is thickened.

  Slow Tape Lean
      To use the texture of a slow machine without the weight, Tape 7.5 ips
      is kept light underneath and brought forward in the mids and top.

  Top Round Only
      To round the top of a harsh digital transfer and nothing else, only
      the high band of Tape 30 ips is raised, so no weight is added.

  Asymmetric Bloom
      To reach the densest harmonic bloom the module can produce, Asymmetry
      is taken to 0.85 on Triode Single-Ended, the one topology where that
      control actually bites.

  Push Pull Firm
      To get a firmer texture with the even orders held back, Asymmetry is
      kept near zero on Triode Push-Pull and the density comes from drive
      and the mid band instead.

  Edge Without Top
      To keep the edge in the guitar range, the high band of Pentode
      Single-Ended is taken well negative. Nothing reaches the cymbals.

  Pentode Weight
      To get weight out of a pentode, the low band of Pentode Push-Pull is
      raised well above anything on the character grid.

  Iron Tighten
      To add iron texture to already bass-heavy material, the low band of
      Transformer Steel is taken negative and tightened.

  Glass Clarity
      To add sheen on top without crowding the midrange, Transformer Nickel
      has its mids pulled back and its top raised, at a low Mix.

Note: only the two Triode entries use Asymmetry. That control is close to
inert on Tape and Pentode and is not wired at all on Transformer, so knowing
where it bites saves a lot of wasted time.

Note: the Saturation and Reverb preset lists are scoped to the Mode. A Tape
preset appears only while the Mode is Tape.


-- enhance/ Enhance (5)

Enhance is five bands, each with its own core, centre, width, amount, drive
and tame - thirty values in all. Choosing a preset sets them together;
placing them one at a time is the part nobody does. These five do that.

  Vocal Sculpt
      To bring out the voice, only the bands it uses are lifted and the
      others are switched off rather than turned down, so nothing else in
      the mix is coloured.

  Bass Definition
      To give the bass definition rather than weight, the low band is moved
      down to 75 Hz, narrowed, and driven hard.

  Cymbal Silk
      To soften hard cymbals and strings, only the top two bands run, both
      on Velvet, with tame set high so the added harmonics stay soft.

  Console Stack
      To build the texture of a studio signal path, every band runs a
      different core - tape, tube tape, triode, pentode, velvet. This is the
      longest entry to reproduce by hand.

  Micro Detail
      To raise detail without adding colour, the wet level is kept very low
      and the per-band drive is raised to compensate, running at eight times
      oversampling to keep it clean.


-- analog/ Analog (5)

The Analog page has controls whose useful settings are not guessable from
the control alone. Crosstalk acts only between its own two corner
frequencies, so where that band sits matters more than the dB figure. Air
Smooth is an all-pass blend whose bell inverts into a notch past about 0.9.

  Headphone Bleed
      To move headphone imaging closer to a pair of speakers, crosstalk is
      placed over 120-900 Hz, the band that carries that imaging, and taken
      to -24 dB. Copying the dB figure alone will not reproduce it.

  Air Smooth Max
      To run Air Smooth at its strongest useful setting, it is set to 0.88.
      Anything higher inverts the bell into a notch, so the limit is here
      rather than at the top of the slider.

  Vinyl Rumble Guard
      To steady the low end the way records were cut, everything below
      150 Hz is summed to mono. That crossover is a value no preset moves
      for you.

  Tape Machine Motion
      To get audible tape motion, wow and flutter is raised to 0.35, with
      the sag it needs so the movement does not read as a fault.

  Center Hold Wide
      To widen the image while keeping the middle in place, the side band
      gains air while Width Protect stops the centre spreading with it. The
      single presets do not offer that combination.


-- reverb/ Reverb (7)

The shipped rooms give you a room. What they do not touch is the shape of
the tail - the early/late balance, and how differently the low and high
halves decay. That is what decides whether a reverb sounds like an effect.

  Early Reflections Only
      To create distance without any ring, the tail is mixed out entirely
      and only the early reflections remain.

  Dark Long Tail
      To get the tail of a real large space, which darkens as it dies, the
      low decay is held long and the high decay is pulled right down. The
      pair is not obvious from the control names.

  Bright Air Tail
      To open a recording without thickening it, the shape is reversed so
      the top of the tail outlasts the bottom.

  Modulated Plate
      To put motion in the late tail, Modulation is raised to 35. It sits
      near zero by default and is the control fewest people ever hear.

  Wide Tail Close Front
      To place the space behind the performance rather than around it, the
      early reflections stay close and narrow while only the tail is widened.

  Ambience Dense
      To read as air rather than as reflections, diffusion is taken near
      maximum and no tail is left at all.

  Bass Free Space
      To stop a reverb muddying everything it touches, the input is cut at
      480 Hz and the low half of the tail is then made to die first.


-- eq/ EQ (6)

These move band type, centre and Q as well as gain. Two of them turn the Sub
band into a high-pass filter, which is the clearest example.

  Spoken Word
      To make speech easier to follow, the Sub band becomes a high-pass at
      80 Hz to remove what a voice never uses, and the consonant range is
      lifted with a narrower bell than the page's default.

  Small Speaker Lift
      To stop a small driver wasting excursion on bass it cannot produce,
      the Sub band becomes a high-pass at 90 Hz and the body is rebuilt in
      the low mids.

  Late Night Soft
      To listen quieter still than Night allows, both ends of the band are
      taken down one further step.

  Bright Room Tame
      To calm a bright, reflective room, the presence dip is moved to
      3.2 kHz and narrowed, and the Air shelf is taken below zero.

  Dull System Lift
      To open a dull system, the top is lifted with a shelf rather than a
      bell, so the lift has no edge to it.

  Bass Line Focus
      To make a bass line audible on a speaker that cannot reach the
      fundamental, the second harmonic near 220 Hz is lifted instead of the
      fundamental itself.


Notes
-----

- Treat each preset as a starting point. Move a control and save the result
  as your own preset with [Save As].
- Pushing several pages hard at once raises the level. Leaving Auto Headroom
  and the Safety Limiter enabled on the Output page is recommended.
- These files carry each page's values directly, so the page reads "Custom"
  after loading one. That is correct.


Terms
-----

This is a convenience pack that makes it easier to try Alauda's settings.
It is free for personal and commercial use. Redistribution is governed by
EULA_jp.txt / EULA_en.txt bundled with Alauda.
The included .aldp preset files may be freely copied, modified, and
redistributed under Article 4, paragraph 3 of the EULA. You may also
redistribute a package containing only these preset files and their
accompanying documentation, including this readme.

Every .aldp file is UTF-8 JSON text. It contains no paths, no scripts and no
binary payload, so you can read exactly what it changes.
